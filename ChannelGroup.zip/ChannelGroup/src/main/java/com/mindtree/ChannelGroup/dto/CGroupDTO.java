package com.mindtree.ChannelGroup.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mindtree.ChannelGroup.entity.Channel;

@JsonInclude(value = Include.NON_NULL)
public class CGroupDTO 
{
	private String groupName;
	
	@JsonIgnoreProperties("cgroup")
	private Set<Channel> channel;

	public CGroupDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Set<Channel> getChannel() {
		return channel;
	}

	public void setChannel(Set<Channel> channel) {
		this.channel = channel;
	}

	
	

}
