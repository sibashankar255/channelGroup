package com.mindtree.ChannelGroup.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ChannelGroup.dto.CGroupDTO;
import com.mindtree.ChannelGroup.dto.ChannelDTO;
import com.mindtree.ChannelGroup.dto.ResponseBody;
import com.mindtree.ChannelGroup.entity.CGroup;
import com.mindtree.ChannelGroup.entity.Channel;
import com.mindtree.ChannelGroup.exception.ApplicationException;
import com.mindtree.ChannelGroup.exception.service.ServiceException;
import com.mindtree.ChannelGroup.service.ChannelService;

@RestController
public class ChannelController 
{
	@Autowired
	private ChannelService channelService;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@PostMapping("/insertChannel")
	public ResponseEntity<?> insertChannel(@RequestBody ChannelDTO channel)
	{
		return new ResponseEntity<ResponseBody<ChannelDTO>>(new ResponseBody<ChannelDTO>(
				modelMapper.map(channelService.insertChannel(modelMapper.map(channel,Channel.class))
						,ChannelDTO.class),null,"Channel Added Successfully",true),HttpStatus.OK);
	}
	
	@PostMapping("/assignGroupToChannel/{groupId}/{channelId}")
	public ResponseEntity<?> assignTrackToLead(@PathVariable long groupId, @PathVariable long channelId) throws ApplicationException
	{
		channelService.assignGroupToChannel(groupId,channelId);
		return new ResponseEntity<ResponseBody<Void>>(new ResponseBody<Void>(
				null, null,"Group Assign To Channel Successfully",true), HttpStatus.OK);
			
	}
	

}
