package com.mindtree.ChannelGroup.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class CShow 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long showId;
	private String showName;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Channel channel;

	public CShow() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getShowId() {
		return showId;
	}

	public void setShowId(long showId) {
		this.showId = showId;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	
	
}
