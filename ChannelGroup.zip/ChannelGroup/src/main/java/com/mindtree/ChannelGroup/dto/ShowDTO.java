package com.mindtree.ChannelGroup.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mindtree.ChannelGroup.entity.Channel;

@JsonInclude(value = Include.NON_NULL)
public class ShowDTO 
{
	private String showName;
	
	@JsonIgnoreProperties("show")
	private Channel channel;

	public ShowDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}
	
}
