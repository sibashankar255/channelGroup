package com.mindtree.ChannelGroup.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Channel implements Comparable<Channel>
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long channelId;
	private String channelName;
	private double channelPrice;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private CGroup cgroup;
	
	@OneToMany(cascade = CascadeType.PERSIST,mappedBy = "channel",fetch = FetchType.EAGER)
	private Set<CShow> cshow;

	public Channel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Set<CShow> getCshow() {
		return cshow;
	}

	public void setCshow(Set<CShow> cshow) {
		this.cshow = cshow;
	}

	public long getChannelId() {
		return channelId;
	}

	public void setChannelId(long channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getChannelPrice() {
		return channelPrice;
	}

	public void setChannelPrice(double channelPrice) {
		this.channelPrice = channelPrice;
	}

	public CGroup getCgroup() {
		return cgroup;
	}

	public void setCgroup(CGroup cgroup) {
		this.cgroup = cgroup;
	}

	@Override
	public int compareTo(Channel o) 
	{
		if(o.getChannelPrice()== this.getChannelPrice())
		{
			if(o.getChannelName().equals(this.getChannelName()))
				return 1;
		}
		else if(o.getChannelPrice()> this.getChannelPrice())
			return 1;
		return -1;
	}
	
}
