package com.mindtree.ChannelGroup.service;

import java.util.List;

import com.mindtree.ChannelGroup.entity.CGroup;
import com.mindtree.ChannelGroup.entity.Channel;
import com.mindtree.ChannelGroup.exception.service.ServiceException;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchGroupException;

public interface GroupService 
{
	CGroup insertGroup(CGroup group);

	List<Channel> displayChannels(long groupId) throws ServiceException;

}
