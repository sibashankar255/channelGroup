package com.mindtree.ChannelGroup.service.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ChannelGroup.entity.CGroup;
import com.mindtree.ChannelGroup.entity.Channel;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchChannelException;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchGroupException;
import com.mindtree.ChannelGroup.repository.ChannelRepository;
import com.mindtree.ChannelGroup.repository.GroupRepository;
import com.mindtree.ChannelGroup.service.ChannelService;

@Service
public class ChannelServiceImpl implements ChannelService
{
	@Autowired
	private ChannelRepository channelRepository;
	
	@Autowired
	private GroupRepository groupRepository;
	
	
	@Override
	public Channel insertChannel(Channel channel) 
	{
		return channelRepository.save(channel);
	}

	@Override
	public void assignGroupToChannel(long groupId, long channelId) throws NoSuchGroupException, NoSuchChannelException 
	{
		CGroup group = groupRepository.findById(groupId).orElseThrow(() -> 
		new NoSuchGroupException("No such group exist"));
		
		Channel channel = channelRepository.findById(channelId).orElseThrow(() -> 
		new NoSuchChannelException("No such channel exist"));
		
		channel.setCgroup(group);
		
		channelRepository.save(channel);
		
	}

}
