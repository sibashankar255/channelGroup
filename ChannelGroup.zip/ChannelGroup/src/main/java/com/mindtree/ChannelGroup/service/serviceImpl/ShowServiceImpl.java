package com.mindtree.ChannelGroup.service.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ChannelGroup.entity.CShow;
import com.mindtree.ChannelGroup.entity.Channel;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchChannelException;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchShowException;
import com.mindtree.ChannelGroup.repository.ChannelRepository;
import com.mindtree.ChannelGroup.repository.ShowRepository;
import com.mindtree.ChannelGroup.service.ShowService;

@Service
public class ShowServiceImpl implements ShowService
{
	@Autowired
	private ShowRepository showRepository;
	
	@Autowired
	private ChannelRepository channelRepository;

	@Override
	public CShow insertShow(CShow show) 
	{
		return showRepository.save(show);
	}

	@Override
	public void assignChannelToShow(long channelId, long showId) throws NoSuchChannelException, NoSuchShowException {
		
		Channel channel = channelRepository.findById(channelId).orElseThrow(() ->
		new NoSuchChannelException("No such channel exist"));
		
		CShow show = showRepository.findById(showId).orElseThrow(() ->
		new NoSuchShowException("No  such Shoow Exist"));
		
		show.setChannel(channel);
		
		showRepository.save(show);
		
		
	}

}
