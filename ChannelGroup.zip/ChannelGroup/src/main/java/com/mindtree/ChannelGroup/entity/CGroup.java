package com.mindtree.ChannelGroup.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class CGroup 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long groupId;
	private String groupName;
	
	@OneToMany(cascade = CascadeType.PERSIST,mappedBy = "cgroup",fetch = FetchType.EAGER)
	private Set<Channel> channel;

	public CGroup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Set<Channel> getChannel() {
		return channel;
	}

	public void setChannel(Set<Channel> channel) {
		this.channel = channel;
	}

	
	
}
