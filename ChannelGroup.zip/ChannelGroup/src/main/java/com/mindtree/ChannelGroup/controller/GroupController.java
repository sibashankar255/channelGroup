package com.mindtree.ChannelGroup.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ChannelGroup.dto.CGroupDTO;
import com.mindtree.ChannelGroup.dto.ChannelDTO;
import com.mindtree.ChannelGroup.dto.ResponseBody;
import com.mindtree.ChannelGroup.entity.CGroup;
import com.mindtree.ChannelGroup.exception.ApplicationException;
import com.mindtree.ChannelGroup.exception.service.ServiceException;
import com.mindtree.ChannelGroup.service.GroupService;


@RestController
public class GroupController 
{
	@Autowired
	private GroupService groupService;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@PostMapping("/insertGroup")
	public ResponseEntity<?> insertGroup(@RequestBody CGroupDTO group)
	{
		return new ResponseEntity<ResponseBody<CGroupDTO>>(new ResponseBody<CGroupDTO>(
				modelMapper.map(groupService.insertGroup(modelMapper.map(group,CGroup.class))
						,CGroupDTO.class),null,"Channel group Added Successfully",true),HttpStatus.OK);
	}
	
	@GetMapping("/displayChannels/{groupId}")
	public ResponseEntity<?> displayChannels(@PathVariable long groupId) throws ApplicationException
	{
		return new ResponseEntity<ResponseBody<List<ChannelDTO>>>(new ResponseBody<List<ChannelDTO>>(
				modelMapper.map(groupService.displayChannels(groupId), new TypeToken<List<ChannelDTO>>() {
				}.getType()), null, "CampusMinds Found", true), HttpStatus.OK);
	}
}


