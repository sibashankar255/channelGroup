package com.mindtree.ChannelGroup.dto;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mindtree.ChannelGroup.entity.CGroup;
import com.mindtree.ChannelGroup.entity.CShow;

@JsonInclude(value = Include.NON_NULL)
public class ChannelDTO 
{
	private String channelName;
	private double channelPrice;
	
//	@JsonIgnoreProperties("channel")
//	private CGroup cgroup;
//	
//	@JsonIgnoreProperties("channel")
//	private Set<CShow> cshow;

	public ChannelDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getChannelPrice() {
		return channelPrice;
	}

	public void setChannelPrice(double channelPrice) {
		this.channelPrice = channelPrice;
	}

//	public CGroup getCgroup() {
//		return cgroup;
//	}
//
//	public void setCgroup(CGroup cgroup) {
//		this.cgroup = cgroup;
//	}
//
//	public Set<CShow> getCshow() {
//		return cshow;
//	}
//
//	public void setCshow(Set<CShow> cshow) {
//		this.cshow = cshow;
//	}


	
	
	

}
