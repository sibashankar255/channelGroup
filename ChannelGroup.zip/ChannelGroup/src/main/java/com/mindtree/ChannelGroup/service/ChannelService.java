package com.mindtree.ChannelGroup.service;

import com.mindtree.ChannelGroup.entity.Channel;
import com.mindtree.ChannelGroup.exception.service.ServiceException;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchGroupException;

public interface ChannelService {

	Channel insertChannel(Channel channel);

	void assignGroupToChannel(long groupId, long channelId) throws ServiceException;

}
