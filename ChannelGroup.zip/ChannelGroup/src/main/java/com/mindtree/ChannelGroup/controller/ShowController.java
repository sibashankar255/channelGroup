package com.mindtree.ChannelGroup.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ChannelGroup.dto.ChannelDTO;
import com.mindtree.ChannelGroup.dto.ResponseBody;
import com.mindtree.ChannelGroup.dto.ShowDTO;
import com.mindtree.ChannelGroup.entity.CShow;
import com.mindtree.ChannelGroup.entity.Channel;
import com.mindtree.ChannelGroup.exception.ApplicationException;
import com.mindtree.ChannelGroup.service.ShowService;

@RestController
public class ShowController 
{
	@Autowired
	private ShowService showService;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@PostMapping("/insertShow")
	public ResponseEntity<?> insertShow(@RequestBody ShowDTO show)
	{
		return new ResponseEntity<ResponseBody<ShowDTO>>(new ResponseBody<ShowDTO>(
				modelMapper.map(showService.insertShow(modelMapper.map(show,CShow.class))
						,ShowDTO.class),null,"Show Added Successfully",true),HttpStatus.OK);
	}
	
	@PostMapping("/assignChannelToShow/{channelId}/{showId}")
	public ResponseEntity<?> assignChannelToShow(@PathVariable long channelId, @PathVariable long showId) throws ApplicationException
	{
		showService.assignChannelToShow(channelId,showId);
		return new ResponseEntity<ResponseBody<Void>>(new ResponseBody<Void>(
				null, null,"Group Assign To Channel Successfully",true), HttpStatus.OK);
			
	}

}
