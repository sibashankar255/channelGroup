package com.mindtree.ChannelGroup.service;

import com.mindtree.ChannelGroup.entity.CShow;
import com.mindtree.ChannelGroup.exception.service.ServiceException;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchChannelException;

public interface ShowService {

	CShow insertShow(CShow show);

	void assignChannelToShow(long channelId, long showId) throws ServiceException;

}
