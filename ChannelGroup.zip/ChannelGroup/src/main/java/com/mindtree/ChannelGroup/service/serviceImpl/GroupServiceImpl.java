package com.mindtree.ChannelGroup.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ChannelGroup.entity.CGroup;
import com.mindtree.ChannelGroup.entity.Channel;
import com.mindtree.ChannelGroup.exception.service.custom.NoSuchGroupException;
import com.mindtree.ChannelGroup.repository.GroupRepository;
import com.mindtree.ChannelGroup.service.GroupService;

@Service
public class GroupServiceImpl implements GroupService
{
	@Autowired
	private GroupRepository groupRepository;

	@Override
	public CGroup insertGroup(CGroup group) 
	{
		return groupRepository.save(group);
	}

	@Override
	public List<Channel> displayChannels(long groupId) throws NoSuchGroupException {
		
		CGroup group = groupRepository.findById(groupId).orElseThrow(() ->
		new NoSuchGroupException("No Such Group Exist"));
	
		Set<Channel> channels = group.getChannel();
		List<Channel> channelList = new ArrayList<Channel>(channels);
		return channelList;
	}

}
