package com.mindtree.ChannelGroup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChannelGroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
